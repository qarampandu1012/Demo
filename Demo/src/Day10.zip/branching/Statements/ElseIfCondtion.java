package branching.Statements;

public class ElseIfCondtion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int value=100;
		
		if(value<1)
		{
			System.out.println("value is Less then 100" );
		}else if(value>1){
			System.out.println("value is Not Less then 100" );
		}else {
			System.out.println("Validation Failed" );	
		}

	}

}
