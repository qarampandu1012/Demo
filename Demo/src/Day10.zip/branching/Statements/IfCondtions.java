package branching.Statements;

public class IfCondtions {

	public static void main(String[] args) {

		int value=10;
		
		if(value>1)
		{
			System.out.println("value is Less then 10" );
		}
		
	}

}
