package branching.Statements;

public class ForloopStatement {

	public static void main(String[] args) {

//int i=2;
//		
//		if(i>1)
//		{
//			System.out.println(i);
//		}
//		
		
		for(int i=1;i<=100;i++)
		{
			System.out.println(i);
		}
		
		
	}

}
