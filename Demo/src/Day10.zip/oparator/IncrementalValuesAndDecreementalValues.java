package oparator;

public class IncrementalValuesAndDecreementalValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		int b = 20;

		System.out.println("Before Increment" + a);

		System.out.println("After Increment" + a++);

		System.out.println("Before Decrement" + b);

		System.out.println("After Decrement" + b--);

		int x = 15;
		int y = 21;
		System.out.println("Before Increment" + (x));
		
		System.out.println("After Increment" + (++x));
		
		
		System.out.println("Before Decrement" + y);

		System.out.println("After Decrement" + (--y));

	}

}
