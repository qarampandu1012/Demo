package oparator;

public class And_Or_Not_OParator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 101;
		int b = 100;
		int c = 20;
		int d = 40;

		if (a == 10 && b == 10) {
			System.out.println("a and b values are 10");
		}

		if (a == 10 || b == 10) {
			System.out.println("a or b values are 10");
		}

		if (a != 10) {
			System.out.println("a Not Equal to 10");
		}
	}

}
