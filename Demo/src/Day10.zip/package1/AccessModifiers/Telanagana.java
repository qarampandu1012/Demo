package package1.AccessModifiers;

public class Telanagana {

	
  public	int x=10;
  protected	int y=10;
  private	int z=11;
	
	int v=90;
	
	public void hyderabad()
	{
		
	}
	
	protected void Warangal()
	{
		
	}
	
	private void Khammam()
	{
		
	}
	
	
	void adilabad()
	{
		
	}
	
	
	
	
	public void myHouse()
	{
		
	}
}
