package ooPs;

public class InterfaceConcept2 implements InterfaceConcept{

	@Override
	public String demo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int demo2() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String demo(String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int demo2(String value) {
		// TODO Auto-generated method stub
		return 0;
	}

}
