package ooPs;

public abstract class AbstractJavaConcept {

	abstract String demo();
	
	
	public void demo2()
	{
		
	}
	
}
