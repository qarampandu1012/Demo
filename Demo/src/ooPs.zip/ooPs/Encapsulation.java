package ooPs;

public class Encapsulation {

	public static String value = "India";
	public static String value2 = "India2";
	public static String value3 = "India3";
	public static String value4 = "India4";



}
