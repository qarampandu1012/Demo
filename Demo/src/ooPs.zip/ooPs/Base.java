package ooPs;

public class Base {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Encapsulation encap=new Encapsulation();
		
		System.out.println(Encapsulation.value);
	}

}
