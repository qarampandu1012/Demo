package ooPs;

public interface InterfaceConcept {

	String value = "Ram";
	int s = 10;

	String demo();

	int demo2();

	String demo(String value);

	int demo2(String value);

}
