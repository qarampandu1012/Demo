package ooPs;

public class MethodOveridingConcept {

	public static String demo123(String value) {
		 value = "Testing";

		return value;
	}
}
