package ooPs;

public class AbstractJavaConcept2  extends AbstractJavaConcept {

	@Override
	String demo() {
		// TODO Auto-generated method stub
		return null;
	}

}
