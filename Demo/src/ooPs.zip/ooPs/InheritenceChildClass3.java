package ooPs;

public class InheritenceChildClass3 extends InheritenceParentClass {

	public void test6() {
		test4();
	}

}
