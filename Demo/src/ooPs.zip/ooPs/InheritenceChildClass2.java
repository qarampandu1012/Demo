package ooPs;

public class InheritenceChildClass2 extends InheritenceParentClass {

	public void test5() {
		  test1();
			}

}
